from pypbbot.plugin import useFilter


def uselessFilter_c():
    return True


@useFilter(uselessFilter_c)
async def plugin_c_hander():
    return